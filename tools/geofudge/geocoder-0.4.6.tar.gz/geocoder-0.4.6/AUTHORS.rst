Geocoder is written and maintained by Denis Carriere.

Development Lead
````````````````

- Denis Carriere <info@addxy.com>